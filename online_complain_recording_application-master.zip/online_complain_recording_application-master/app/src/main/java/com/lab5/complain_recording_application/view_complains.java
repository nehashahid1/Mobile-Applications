package com.lab5.complain_recording_application;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class view_complains extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_complains);
    }
}
